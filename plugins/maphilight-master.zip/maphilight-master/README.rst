==========
Maphilight
==========

Maphilight is a jQuery plugin that adds visual hilights to image maps.

It provides a single jQuery function: ``$('.foo').maphilight()``

In IE VML is used. In other browsers canvas is used. Maphilight has been
tested in Firefox, IE, Safari, Chrome, and Opera.

Documentation is included in the ``docs`` directory, or can be found
at http://davidlynch.org/js/maphilight/docs/
